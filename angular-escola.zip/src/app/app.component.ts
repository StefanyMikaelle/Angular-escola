import { Component } from '@angular/core';
import { Disciplina } from './disciplina.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  selecionado = null;
  nome = null;
  descricao = null;
  editando = null;

  disciplinas = [
    new Disciplina('Língua Portuguesa',
     'O objetivo norteador da BNCC de Língua Portuguesa é ' +
      'garantir a todos os alunos o acesso aos saberes ' +
      'linguísticos necessários para a participação social e o exercício ' +
      'da cidadania, pois é por meio da língua que ' +
      'o ser humano pensa, comunica-se, tem acesso à informação, expressa ' +
      'e defende pontos de vista, partilha ou ' +
      'constrói visões de mundo e produz conhecimento.'),
    new Disciplina('Língua Portuguesa',
      'O objetivo norteador da BNCC de Língua Portuguesa é ' +
       'garantir a todos os alunos o acesso aos saberes ' +
       'linguísticos necessários para a participação social e o exercício ' +
       'da cidadania, pois é por meio da língua que ' +
       'o ser humano pensa, comunica-se, tem acesso à informação, expressa ' +
       'e defende pontos de vista, partilha ou ' +
       'constrói visões de mundo e produz conhecimento.'),
    new Disciplina('Língua Portuguesa',
       'O objetivo norteador da BNCC de Língua Portuguesa é ' +
        'garantir a todos os alunos o acesso aos saberes ' +
        'linguísticos necessários para a participação social e o exercício ' +
        'da cidadania, pois é por meio da língua que ' +
        'o ser humano pensa, comunica-se, tem acesso à informação, expressa ' +
        'e defende pontos de vista, partilha ou ' +
        'constrói visões de mundo e produz conhecimento.')
  ];

  selecionar(disciplina) {
    this.selecionado = disciplina;
  }

  salvar() {
    if (this.editando) {
      this.editando.nome = this.nome;
      this.editando.descricao = this.descricao;
    } else {
      const d = new Disciplina(this.nome, this.descricao);
      this.disciplinas.push(d);
    }
    this.nome = null;
    this.descricao = null;
    this.editando = null;
  }
  excluir(disciplina) {
    if (this.editando == disciplina) {
      alert('Você não pode excluir uma disciplina que está editando');
    } else {
      if (confirm('Tem certeza que deseja excluir a disciplina "'
          + disciplina.nome + '"?')) {
        const i = this.disciplinas.indexOf(disciplina);
        this.disciplinas.splice(i, 1);
      }
    }
  }
  editar(disciplina) {
    this.nome = disciplina.nome;
    this.descricao = disciplina.descricao;
    this.editando = disciplina;
  }
  cancelar() {
    this.nome = null;
    this.descricao = null;
    this.editando = null;
  }
  
}
